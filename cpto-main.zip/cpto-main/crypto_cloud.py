import os
import asyncio
import time
import requests
import random
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

# ======================
# CONFIGURATION (CLOUD SAFE)
# ======================
BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")

if not BOT_TOKEN or not CHAT_ID:
    raise ValueError("⚠️ ERROR: Variabel lingkungan TELEGRAM_BOT_TOKEN atau TELEGRAM_CHAT_ID belum diatur!")

# ======================
# CACHE SYSTEM
# ======================
cache_data = {
    "trending": None,
    "market": None,
    "kurs": None,
    "last_trending_fetch": 0,
    "last_market_fetch": 0,
    "last_kurs_fetch": 0
}
CACHE_DURATION = 60 

# ======================
# PROXY & REQUEST ENGINE (ANTI 429)
# ======================
# Daftar proxy publik gratisan sebagai jalur cadangan jika IP Railway diblokir
PROXIES_POOL = [
    "https://api.allorigins.win/get?url=",
    "https://api.codetabs.com/v1/proxy/?quest="
]

def fetch_via_proxy(target_url):
    """Mencoba mengambil data langsung, jika diblokir (429) akan otomatis beralih lewat proxy jalur tikus."""
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
    
    # Percobaan 1: Tembak Langsung
    try:
        res = requests.get(target_url, headers=headers, timeout=10)
        if res.status_code == 200:
            return res.json()
        print(f"Direct fetch failed with status: {res.status_code}. Trying proxy...")
    except Exception as e:
        print(f"Direct fetch exception: {e}. Trying proxy...")

    # Percobaan 2 & 3: Lewat Jalur Tikus (Proxy)
    random.shuffle(PROXIES_POOL)
    for proxy in PROXIES_POOL:
        try:
            proxy_url = f"{proxy}{target_url}"
            res = requests.get(proxy_url, timeout=12)
            if res.status_code == 200:
                # allorigins membungkus datanya di dalam field 'contents' berbentuk string
                if "allorigins" in proxy:
                    import json
                    return json.loads(res.json()["contents"])
                return res.json()
        except Exception as proxy_e:
            print(f"Proxy {proxy} gagal: {proxy_e}")
            
    return None

# ======================
# DATA FETCHING
# ======================

def get_trending():
    current_time = time.time()
    if cache_data["trending"] and (current_time - cache_data["last_trending_fetch"] < CACHE_DURATION):
        return cache_data["trending"]

    url = "https://api.coingecko.com/api/v3/search/trending"
    data = fetch_via_proxy(url)
    if data and "coins" in data:
        cache_data["trending"] = data.get("coins", [])
        cache_data["last_trending_fetch"] = current_time
        return cache_data["trending"]
        
    return cache_data["trending"] if cache_data["trending"] else []

def get_market():
    current_time = time.time()
    if cache_data["market"] and (current_time - cache_data["last_market_fetch"] < CACHE_DURATION):
        return cache_data["market"]

    url = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&per_page=250&page=1"
    data = fetch_via_proxy(url)
    if data and isinstance(data, list):
        cache_data["market"] = data
        cache_data["last_market_fetch"] = current_time
        return data
        
    return cache_data["market"] if cache_data["market"] else []
    
def get_live_kurs():
    current_time = time.time()
    if cache_data["kurs"] and (current_time - cache_data["last_kurs_fetch"] < CACHE_DURATION):
        return cache_data["kurs"]

    url = "https://api.coingecko.com/api/v3/simple/price?ids=tether&vs_currencies=idr"
    data = fetch_via_proxy(url)
    if data and 'tether' in data:
        cache_data["kurs"] = float(data['tether']['idr'])
        cache_data["last_kurs_fetch"] = current_time
        return cache_data["kurs"]
        
    return 16250.0

# ======================
# CORE LOGIC ENGINE
# ======================

def build_message():
    trending = get_trending()
    market = get_market()

    if not trending or not market:
        return "⚠️ Gagal mengambil data pasar (Semua jalur IP terblokir). Mencoba kembali nanti..."

    msg = "🔥 DAILY CRYPTO NARRATIVE\n\n"
    found = False
    index = 1

    for coin in trending:
        item = coin.get("item", {})
        coin_id = item.get("id")
        name = item.get("name")

        data = next((c for c in market if c.get("id") == coin_id), None)
        if not data:
            continue

        price = data.get("price_change_percentage_24h")
        vol = data.get("total_volume")

        if price is None or vol is None or price < 0 or vol < 10_000_000:
            continue

        score = 0
        reason = []

        if price > 5:
            score += 2
            reason.append("price up strong")
        elif price > 2:
            score += 1
            reason.append("price up")

        if vol > 50_000_000:
            score += 1
            reason.append("high volume")

        if item.get("score", 99) < 5:
            score += 1
            reason.append("trending")

        if score < 2:
            continue

        label = "🚀 Strong" if score >= 3 else "🔥 Hot"
        stage = "🟢 EARLY" if price <= 6 else ("🟡 MID" if price <= 15 else "🔴 LATE")
        found = True

        msg += f"{index}. {name} ({data['symbol'].upper()})\n"
        msg += f"💰 Price: ${data['current_price']}\n"
        msg += f"📈 24h: {price:.2f}%\n"
        msg += f"💧 Volume: {round(vol/1_000_000)}M\n"
        msg += f"⚡ Signal: {label}\n"
        msg += f"📊 Stage: {stage}\n"
        msg += f"🧠 Reason: {', '.join(reason)}\n\n"
        index += 1

    if not found:
        msg += "⚠️ No strong narrative detected today."
    return msg

# ======================
# ASYNC COMMAND HANDLERS
# ======================

async def start_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (
        "🤖 Crypto Scanner Bot (Cloud Version)\n\n"
        "👉 /scan   — Semua signal market\n"
        "👉 /early  — Entry awal (belum naik banyak)\n"
        "👉 /smart  — Deteksi uang besar masuk\n"
        "👉 /hype   — Lihat coin yang lagi rame\n"
        "👉 /narrative — Lihat sektor yang lagi naik\n"
        "👉 /monitor — Cek target VET & kurs USDT/IDR"
    )
    await update.message.reply_text(text)

async def scan_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🔍 Scanning market...")
    await update.message.reply_text(build_message())

async def early_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🧠 Scanning EARLY opportunities...")
    trending = get_trending()
    market = get_market()

    msg = "🧠 EARLY OPPORTUNITIES\n\n"
    found = False
    index = 1

    for coin in trending:
        data = next((c for c in market if c.get("id") == coin.get("item", {}).get("id")), None)
        if not data: continue
        
        price = data.get("price_change_percentage_24h")
        vol = data.get("total_volume")
        if price is None or vol is None or not (2 <= price <= 8) or vol < 20_000_000:
            continue

        found = True
        msg += f"{index}. {data['name']} ({data['symbol'].upper()})\n"
        msg += f"💰 Price: ${data['current_price']}\n"
        msg += f"📈 24h: {price:.2f}%\n"
        msg += f"💧 Volume: {round(vol/1_000_000)}M\n"
        msg += f"🟢 Stage: EARLY\n\n"
        index += 1

    if not found: msg += "⚠️ No early opportunities found."
    await update.message.reply_text(msg)

async def smart_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("💸 Scanning Smart Money...")
    trending = get_trending()
    market = get_market()

    msg = "💸 SMART MONEY & ACCUMULATION ALERT\n\n"
    found = False
    index = 1

    for coin in trending:
        data = next((c for c in market if c.get("id") == coin.get("item", {}).get("id")), None)
        if not data: continue

        price_change = data.get("price_change_percentage_24h")
        current_vol = data.get("total_volume")
        market_cap = data.get("market_cap")

        if not price_change or not current_vol or not market_cap or market_cap == 0:
            continue

        v_ratio = (current_vol / market_cap) * 100
        if (0.5 <= price_change <= 4.0) and current_vol > 20_000_000 and v_ratio > 15.0:
            found = True
            label = "💎 INSANE ACCUMULATION" if v_ratio > 30 else "✅ STRONG ACCUMULATION"
            msg += f"{index}. {data['name']} ({data['symbol'].upper()})\n"
            msg += f"📈 Change: {price_change:.2f}%\n"
            msg += f"💧 Vol/MCap Ratio: {v_ratio:.1f}%\n"
            msg += f"💰 Vol: {round(current_vol/1_000_000)}M\n"
            msg += f"🛡️ Status: {label}\n\n"
            index += 1

    if not found: msg += "⚠️ Belum ada tanda akumulasi besar di harga bawah."
    await update.message.reply_text(msg)

async def hype_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🔥 Scanning Market Hype...")
    trending = get_trending()
    market = get_market()

    msg = "🔥 MARKET HYPE DETECTOR\n\n"
    found = False
    index = 1

    for coin in trending:
        item = coin.get("item", {})
        data = next((c for c in market if c.get("id") == item.get("id")), None)
        if not data: continue

        price = data.get("price_change_percentage_24h")
        vol = data.get("total_volume")
        if price is None or vol is None: continue

        hype_score = 0
        if item.get("score", 99) < 3: hype_score += 2
        if vol > 50_000_000: hype_score += 1
        if price > 5: hype_score += 1

        if hype_score < 2: continue
        found = True
        label = "🔥 VERY HOT" if hype_score >= 3 else "🟡 WARM"

        msg += f"{index}. {data['name']} ({data['symbol'].upper()})\n"
        msg += f"📈 {price:.2f}%\n"
        msg += f"💧 {round(vol/1_000_000)}M\n"
        msg += f"🔥 Hype: {label}\n\n"
        index += 1

    if not found: msg += "⚠️ No hype detected."
    await update.message.reply_text(msg)

async def narrative_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("🗣️ Membaca obrolan pasar...")
    trending = get_trending()

    if not trending:
        await update.message.reply_text("⚠️ Gagal memantau obrolan pasar.")
        return

    msg = "🗣️ HOT TOPICS / NARRATIVE\n\n"
    for i, coin in enumerate(trending[:7], start=1):
        item = coin.get("item", {})
        msg += f"{i}. {item.get('name')} ({item.get('symbol','').upper()})\n"
        msg += f"🏆 Rank: #{item.get('market_cap_rank','---')}\n\n"

    await update.message.reply_text(msg)

async def monitor_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    kurs = get_live_kurs()
    market = get_market()

    msg = f"🎯 WATCHLIST REPORT\n(Kurs USDT: Rp {kurs:,.0f})\n\n"
    WATCHLIST = ["vechain", "bitcoin", "polygon-ecosystem-token"]

    for coin_id in WATCHLIST:
        data = next((c for c in market if c.get("id") == coin_id), None)
        if not data: continue

        price_idr = data.get('current_price', 0) * kurs
        symbol = data.get('symbol', '').upper()
        alert = "⏳ Fase akumulasi/tunggu."

        if symbol == "VET":
            if price_idr <= 120: alert = "🚨 AREA BUY! Sangat murah."
            elif price_idr >= 800: alert = "🚀 TARGET ATH! Waktunya jual."

        msg += f"🪙 {data.get('name')} ({symbol})\n"
        msg += f"💵 Harga: Rp {price_idr:,.2f}\n"
        msg += f"📊 24h: {data.get('price_change_percentage_24h', 0):.2f}%\n"
        msg += f"💡 Note: {alert}\n\n"

    await update.message.reply_text(msg)

# ======================
# BACKGROUND JOBS
# ======================

async def cron_loop(context: ContextTypes.DEFAULT_TYPE):
    try:
        kurs = get_live_kurs()
        market = get_market()
        vet = next((c for c in market if c.get("id") == "vechain"), None)
        
        if vet:
            price_idr = vet.get('current_price', 0) * kurs
            if price_idr <= 120:
                await context.bot.send_message(
                    chat_id=CHAT_ID,
                    text=f"🚨 VET RP 120 DETECTED!\nHarga: Rp {price_idr:,.2f}\nCek Exchange!"
                )
    except Exception as e:
        print(f"Error background job: {e}")

# ======================
# MAIN EXECUTION
# ======================

if __name__ == "__main__":
    print("Bot Cloud Starting...")
    
    app = ApplicationBuilder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start_cmd))
    app.add_handler(CommandHandler("scan", scan_cmd))
    app.add_handler(CommandHandler("early", early_cmd))
    app.add_handler(CommandHandler("smart", smart_cmd))
    app.add_handler(CommandHandler("hype", hype_cmd))
    app.add_handler(CommandHandler("narrative", narrative_cmd))
    app.add_handler(CommandHandler("monitor", monitor_cmd))

    if app.job_queue:
        app.job_queue.run_repeating(cron_loop, interval=300, first=10)

    app.run_polling()
